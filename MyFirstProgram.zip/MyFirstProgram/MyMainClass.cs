﻿using System;

namespace MyFirstProgram
{
    internal class MyMainClass
    {
        static void Main()
        {
            Console.WriteLine("******************************************");
            Console.WriteLine("**    Hello World, I’m Megan Arrowood   **");
            Console.WriteLine("******************************************");

        }
    }
}
