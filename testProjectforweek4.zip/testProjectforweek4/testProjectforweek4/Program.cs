﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Car Loan Amortization Calculator");

        // Get user input
        Console.Write("Enter the amount of the car loan: ");
        double loanAmount = Convert.ToDouble(Console.ReadLine());

        Console.Write("Enter the Annual Percentage Rate (APR): ");
        double apr = Convert.ToDouble(Console.ReadLine());

        Console.Write("Enter the monthly car payment including interest: ");
        double monthlyPayment = Convert.ToDouble(Console.ReadLine());

        // Calculate monthly interest rate and number of payments
        double monthlyInterestRate = (apr / 100) / 12;
        int numberOfPayments = (int)Math.Ceiling(loanAmount / monthlyPayment);

        // Calculate amortization schedule
        double remainingBalance = loanAmount;
        double totalPaid = 0;
        double totalInterestPaid = 0;

        for (int month = 1; month <= numberOfPayments; month++)
        {
            double interestPayment = remainingBalance * monthlyInterestRate;
            double principalPayment = monthlyPayment - interestPayment;

            remainingBalance -= principalPayment;
            totalPaid += monthlyPayment;
            totalInterestPaid += interestPayment;

            Console.WriteLine($"Month {month}: Payment: {monthlyPayment:C}, Principal: {principalPayment:C}, Interest: {interestPayment:C}, Remaining Balance: {remainingBalance:C}");
        }

        // Display summary
        Console.WriteLine("\nSummary:");
        Console.WriteLine($"Total Amount Paid: {totalPaid:C}");
        Console.WriteLine($"Total Interest Paid: {totalInterestPaid:C}");
        Console.WriteLine($"Number of Months: {numberOfPayments}");

        Console.ReadLine(); // Keep the console window open
    }
}
