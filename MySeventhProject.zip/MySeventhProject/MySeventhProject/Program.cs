﻿using System;
using System.ComponentModel.Design;
using System.Diagnostics;
using static System.Console;



class Item
{
    public int number { get; set; }
    public string description { get; set; }
    public double price { get; set; }

    public Item(int number, string description, double price)
    {
        this.number = number;
        this.description = description;
        this.price = price;
    }

    public void Display()
    {
        
        Console.WriteLine($"Price for {description} is {price:C}");
    }
}

class mySeventhProgram
{

    public static void Main()


    {
        Item[] items =
     {
        new Item(45, "Book", 21.17),
        new Item(70, "Keyboard", 47.29),
        new Item(97, "Earbuds", 27.29),
        new Item(20, "Mouse", 26.46),
        new Item(19, "Video Game", 47.80),
        new Item(50, "Bag of Coffee", 7.82),
        new Item(38, "Fancy Mug", 44.52),
        new Item(46, "Pie", 3.14),
};

        Write("Enter an item number. ");

        string itemString = Console.ReadLine();
        int itemOrdered;

        if (!int.TryParse(itemString, out itemOrdered))
        {
            Console.WriteLine("Invalid input. Please enter a valid item number.");
            return;
        }

        bool isValidItem = false;

        foreach (var item in items)
        {
            if (item.number == itemOrdered)
            {
                isValidItem = true;
                item.Display();
                break;
            }
        }

        if (!isValidItem)
        {
            Console.WriteLine("Item not found");
        }
    }
}