﻿using System;
using System.Globalization;
using System.Net.Http.Headers;
using static System.Console;
class MyMainClass
{
    public static void Main()
    {
       
      
        string slicesString;
        double slices;
        string size;
        string sizeM = "M";
        string sizeL = "L";

        Write("Would you like to buy an entire pizza (1) or buy a slice (2)? ");
        string pizzaString;
        double pizza;
        pizzaString = ReadLine();
        pizza = Convert.ToDouble(pizzaString);

        if (pizza == 1)
        {
            WriteLine(" Entire Pizza! Please enter (M) or (L) for Medium or Large");
            size = ReadLine();
            if (size == sizeM)
            { 

                WriteLine("Medium! How Many toppings would you like?");
                string toppingsMedString = ReadLine();
                double toppingsMedium = Convert.ToDouble(toppingsMedString);

                double priceMedium = toppingsMedium * 1 + 7;
                
                WriteLine($"Medium pizza with {toppingsMedium} toppings is {priceMedium.ToString("C", CultureInfo.GetCultureInfo("en-US"))}");


            }

            else if  (size == sizeL)


             {
                WriteLine("Large! How Many toppings would you like? ");
                string toppingsLgString = ReadLine();
                double toppingsLarge = Convert.ToDouble(toppingsLgString);

                double priceLarge = toppingsLarge * 1 + 10;
                WriteLine($"Large pizza with {toppingsLarge} toppings is {priceLarge.ToString("C", CultureInfo.GetCultureInfo("en-US"))}");

            }

            else
             WriteLine("Enter (M) or (L)!!!!!!");

        }
        else if (pizza == 2)
        {

            WriteLine(" How many slices would you like?");
            slicesString = ReadLine();
            slices = Convert.ToDouble(slicesString);
            double sliceTPrice = slices * 2;


            WriteLine($"{slices} slice(s) of pizza is {sliceTPrice.ToString("C", CultureInfo.GetCultureInfo("en-US"))}. Thank You!");

            


        }
        
        else
           {
               WriteLine("Enter a 1 or 2!");
           }
    
    

          
    }

}   



