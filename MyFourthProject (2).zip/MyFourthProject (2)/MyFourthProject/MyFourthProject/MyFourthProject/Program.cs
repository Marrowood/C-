﻿using System;
using System.Globalization;
using static System.Console;
using static System.Net.Mime.MediaTypeNames;

class MyFourthProgram
{
    public static void Main()
    {
        string  loanAmountAsString, interestAsString, monthlyPaymentAsString; 
        double loanAmount, interestRate, monthlyPayment, currentMonthInterest, monthlyPrinciple, remainingBalance;

        Write("Enter the total loan amount: ");
        loanAmountAsString = ReadLine();
        loanAmount = Convert.ToDouble(loanAmountAsString);


        Write("What is your intrest rate: ");
        interestAsString = ReadLine();
        interestRate = Convert.ToDouble(interestAsString);

        Write("What is the monthly payment: ");
        monthlyPaymentAsString = ReadLine();
        monthlyPayment = Convert.ToDouble(monthlyPaymentAsString);

       

        double interestMonthly = (interestRate / 12) / 100;

        WriteLine("Month - Interest - Principle -    Balance");
       

        for (int month = 1; month <= 12; month++)
        {

            // Calculate the intrest rate for the current month.
            Write($"{month,5}");

            currentMonthInterest = (loanAmount * interestMonthly); Math.Round(currentMonthInterest, 2);

            Write($"{currentMonthInterest.ToString("C", CultureInfo.GetCultureInfo("en-US")),11}");

            //Calculate monthy principle

            monthlyPrinciple = monthlyPayment - currentMonthInterest;

            Write($"{monthlyPrinciple.ToString("C", CultureInfo.GetCultureInfo("en-US")),12}");

            //Calculate remaning balance


            remainingBalance = loanAmount + currentMonthInterest - monthlyPayment;
            Write($"{remainingBalance.ToString("C", CultureInfo.GetCultureInfo("en-US")),13}");
        }

    }
}