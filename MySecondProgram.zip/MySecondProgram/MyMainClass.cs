﻿using System;
using System.Globalization;

namespace MySecondProgram
{
    internal class MyMainClass
    {
        public static void Main()
        {
            String subtotalString;
            String tipAsString;
            double tipPercent;
            double subtotal;
            const double salesTax = 0.06;
            double subtotalPlusTax;
            double subTotalTax;
            double tipValue;
            double tipTotal;
            double finalTotal;



            Console.WriteLine("Enter the subtotal amount: ");
            subtotalString = Console.ReadLine();
            subtotal = Convert.ToDouble(subtotalString);




            subTotalTax = (subtotal * salesTax);
            subtotalPlusTax = (subTotalTax + subtotal);
            
            Console.WriteLine("Enter the tip percent for " + subtotalPlusTax.ToString("C", CultureInfo.GetCultureInfo("en-US")) + ":");
            tipAsString = Console.ReadLine();
            tipPercent = Convert.ToDouble(tipAsString);

            tipValue = tipPercent / 100;
            tipTotal = (subtotalPlusTax * tipValue);
            finalTotal =(tipTotal + subtotalPlusTax);
            Console.WriteLine("-------------------");
            Console.WriteLine($"Subtotal:{ subtotal.ToString("C", CultureInfo.GetCultureInfo("en-US")),10}");
            Console.WriteLine($"Tax 6%:{ subTotalTax.ToString("C", CultureInfo.GetCultureInfo("en-US")),12}");
            Console.WriteLine("             " + subtotalPlusTax.ToString("C", CultureInfo.GetCultureInfo("en-US")));
            Console.WriteLine("Tip " + tipPercent + "%:      "  + tipTotal.ToString("C", CultureInfo.GetCultureInfo("en-US")));
            Console.WriteLine("-------------------");
            Console.WriteLine("Total:       " + finalTotal.ToString("C", CultureInfo.GetCultureInfo("en-US"))); ;


        }
    }
}
