﻿using System;
using System.Globalization;
using static System.Console;
using static System.Net.Mime.MediaTypeNames;

class MyFourthProgram
{
    public static void Main()
    {
        string loanAmountAsString, interestAsString, monthlyPaymentAsString;
        double loanAmount, interestRate, monthlyPayment ;

        Write("Enter the total loan amount: ");
        loanAmountAsString = ReadLine();
        loanAmount = Convert.ToDouble(loanAmountAsString);


        Write("What is your intrest rate: ");
        interestAsString = ReadLine();
        interestRate = Convert.ToDouble(interestAsString);

        Write("What is the monthly payment: ");
        monthlyPaymentAsString = ReadLine();
        monthlyPayment = Convert.ToDouble(monthlyPaymentAsString);



            int months = 0;
            double totalPaid = 0;
            double totalInterest = 0;
            double remainingBalance = loanAmount;

            while (remainingBalance > 0)
            {
                // Calculate monthly interest rate
                double monthlyInterestRate = interestRate / 12 / 100;

                // Calculate interest for the current month
                double interest = Math.Round(remainingBalance * monthlyInterestRate, 2);

                // Calculate principal paid for the current month
                double principalPaid = Math.Round(monthlyPayment - interest, 2);

                // Calculate the remaining balance
                remainingBalance = Math.Round(remainingBalance + interest - monthlyPayment, 2);

                // Adjust the last payment if necessary
                if (remainingBalance < 0)
                {
                    principalPaid = Math.Round(principalPaid + remainingBalance, 2);
                    remainingBalance = 0;
                }

               
               
            

  
                totalPaid += monthlyPayment;
                totalInterest += interest;


                Write($"{++months,5}");
                Write($"{interest.ToString("C", CultureInfo.GetCultureInfo("en-US")),11}");
                Write($"{principalPaid.ToString("C", CultureInfo.GetCultureInfo("en-US")),12}");
                WriteLine($"{remainingBalance.ToString("C", CultureInfo.GetCultureInfo("en-US")),13}");



            }
            WriteLine($"Total Paid: {totalPaid:C} Total Interest: {totalInterest:C} Months: {months}");

        }
    } 