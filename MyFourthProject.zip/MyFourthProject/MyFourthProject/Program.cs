﻿using System;
using static System.Console;

class MyFourthProgram
{
    public static void Main()
    {
        string  loanAmountAsString, interestAsString, monthlyPaymentAsString; 
        double loanAmount, interestAmount, monthlyAmount; 

        Write("Enter the total loan amount: ");
        loanAmountAsString = ReadLine();
        loanAmount = Convert.ToDouble(loanAmountAsString);


        Write("What is your intrest rate: ");
        interestAsString = ReadLine();
        interestAmount = Convert.ToDouble(interestAsString);

        Write("What is the monthly payment: ");
        monthlyPaymentAsString = ReadLine();
        monthlyAmount = Convert.ToDouble(monthlyPaymentAsString);
    }
}