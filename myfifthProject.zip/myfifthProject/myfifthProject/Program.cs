﻿using System;
using System.ComponentModel.Design;
using static System.Console;

class myfifthProject
{

    public static void Main()


    {
        int i;
        string itemString;
        int itemOrdered;
        double itemPrice;
        bool isValidItem = false;
        int[] validItems = { 45, 70, 94, 20, 19, 50, 38, 46 };
        string[] descriptions = { "Book", "Keyboard", "Earbuds", "Mouse", "Video Game", "Bag of Coffee", "Fancy Mug", "Pie" };

        double[] prices = { 21.17, 47.29, 27.29, 26.46, 47.80, 7.82, 44.52, 3.14 };


        Write("Enter an item number. ");

        itemString = ReadLine();

        itemOrdered = Convert.ToInt32(itemString);

        i = 0;

        while( i < validItems.Length && itemOrdered != validItems[i] ) i++;
       
        
        if( i != validItems.Length)
        {
            isValidItem = true;
            itemPrice = prices[i];
        }
        if (isValidItem)

            WriteLine($"Price for {descriptions[i]} is {prices[i]:C}");

        else
            WriteLine("Item not found");
        
    }
}