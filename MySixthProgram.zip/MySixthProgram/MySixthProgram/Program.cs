﻿using System;
using System.ComponentModel.Design;
using System.Diagnostics;
using System.Timers;
using static System.Console;

internal class MyMainClass
{
    static void Main()
    {
        
        int theNumber = getNumber();
       
        WriteLine($"You Entered {theNumber}");

        
    }

    static int getNumber(int lowerLimit = 0, int upperLimit = 10)
    {
        int number;
        do
        {

            WriteLine("Enter a number between 0 and 10:");
            string numberAsString = ReadLine();
             number = Convert.ToInt32(numberAsString); ;
        }
            while (number < lowerLimit || number > upperLimit);

            return number;
        
    }
}